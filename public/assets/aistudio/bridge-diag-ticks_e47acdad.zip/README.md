Replace bridge/server.py. Only /api/diag changed: it now prints 6 raw live ticks (symbol, price, clock skew)
next to the last history close. Restart the bridge first so it starts with a fresh Pocket Option session.
