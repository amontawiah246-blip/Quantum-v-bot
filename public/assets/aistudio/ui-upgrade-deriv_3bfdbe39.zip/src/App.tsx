import React, { useEffect, useRef, useState } from "react";
import { Activity, ChevronDown, Code, Ellipsis, House, Menu as MenuIcon } from "lucide-react";
import ChartView, { ChartHandle } from "./ChartView";
import Sheet from "./Sheet";
import BrokerMenu, { BrokerLogo } from "./BrokerMenu";
import MarketPicker from "./MarketPicker";
import MarketIcon from "./MarketIcon";
import ChartMenu from "./ChartMenu";
import { ModeBox, ModePopup } from "./ModePicker";
import { Home, Signals, Api, Menu, StatusData } from "./Pages";
import { shortName, TIMEFRAMES, BROKERS, Asset, ChartType, CHART_TYPES, Mode, MODES } from "./assets";
import "./styles.css";

const defaultBridge = () => {
  if (typeof window === "undefined") return "localhost:3000";
  const saved = localStorage.getItem("bridge");
  if (saved && !saved.includes(":8765")) {
    return saved;
  }
  return location.host;
};

// Small helpers: remember a choice in this browser, never crash if storage is blocked.
function remembered<T extends string>(key: string, allowed: readonly T[], fallback: T): T {
  try {
    const v = localStorage.getItem(key) as T | null;
    if (v && allowed.includes(v)) return v;
  } catch { /* storage unavailable */ }
  return fallback;
}
const remember = (key: string, value: string) => { try { localStorage.setItem(key, value); } catch { /* ignore */ } };

export default function App() {
  const [tab, setTab] = useState("chart");
  const [bridge, setBridgeState] = useState(defaultBridge);
  const [broker, setBroker] = useState("pocket");
  const [asset, setAsset] = useState("EURUSD_otc");
  const [tf, setTf] = useState(60);
  const [sheet, setSheet] = useState<string | null>(null); // broker | pair | tf | more
  const [assets, setAssets] = useState<Asset[]>([]);
  const [status, setStatus] = useState<StatusData | null>(null);
  const [reloadKey, setReloadKey] = useState(0);
  const [chartType, setChartTypeState] = useState<ChartType>(() => remembered("qx-chart-type", CHART_TYPES.map((c) => c.id), "candles"));
  const [mode, setModeState] = useState<Mode>(() => remembered("qx-mode", MODES.map((m) => m.id), "classic"));
  const [modePop, setModePop] = useState(false);
  const [toast, setToast] = useState("");
  const chartRef = useRef<ChartHandle>(null);

  const setBridge = (v: string) => {
    localStorage.setItem("bridge", v);
    setBridgeState(v);
  };
  const setChartType = (t: ChartType) => { setChartTypeState(t); remember("qx-chart-type", t); };
  const setMode = (m: Mode) => { setModeState(m); remember("qx-mode", m); };

  const isHttps = typeof window !== "undefined" && window.location.protocol === "https:";
  const isLocal = bridge.includes("localhost") || bridge.includes("127.0.0.1");
  const httpProto = isHttps && !isLocal ? "https" : "http";
  const wsProto = isHttps && !isLocal ? "wss" : "ws";
  const http = bridge.startsWith("http") ? bridge : `${httpProto}://${bridge}`;
  const wsBase = bridge.startsWith("ws") ? bridge : `${wsProto}://${bridge}`;

  // Status + asset list (payouts change, so refresh every minute).
  useEffect(() => {
    let dead = false;
    const load = async () => {
      try {
        const sRes = await fetch(`${http}/api/status?broker=${broker}`);
        if (sRes.ok) {
          const s = await sRes.json();
          if (!dead) setStatus(s);
        } else if (!dead) {
          setStatus(null);
        }

        const aRes = await fetch(`${http}/api/assets?broker=${broker}`);
        if (aRes.ok) {
          const a = await aRes.json();
          if (!dead && Array.isArray(a)) {
            setAssets(a);
            if (a.length > 0 && !a.some((x) => x.symbol === asset)) {
              setAsset(a[0].symbol);
            }
          }
        }
      } catch {
        if (!dead) setStatus(null);
      }
    };
    load();
    const id = setInterval(load, status?.ready ? 60000 : 3000);
    return () => { dead = true; clearInterval(id); };
  }, [http, broker, status?.ready]);

  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(""), 2400);
    return () => clearTimeout(id);
  }, [toast]);

  const current = assets.find((a) => a.symbol === asset);
  const currentAsset: Asset = current ?? { symbol: asset };
  const tfLabel = TIMEFRAMES.find((t) => t.sec === tf)?.label;
  const brokerName = BROKERS.find((b) => b.id === broker)?.name || "Pocket Option";
  const modeInfo = MODES.find((m) => m.id === mode);

  const close = () => setSheet(null);
  const go = (id: string) => { setTab(id); setSheet(null); setModePop(false); };
  const toggleSheet = (id: string) => { setModePop(false); setSheet((s) => (s === id ? null : id)); };

  const navBtn = (id: string, name: string, icon: React.ReactNode) => (
    <button key={id} className={tab === id ? "on" : ""} onClick={() => go(id)}>
      {icon}
      <span>{name}</span>
    </button>
  );

  return (
    <div className="app">
      {tab === "chart" && (
        <header className="top">
          <button className="chip brk" onClick={() => { setModePop(false); setSheet("broker"); }}>
            <BrokerLogo id={broker} size={26} />
            <span>{brokerName.split(" ")[0].toUpperCase()}</span>
            <ChevronDown size={16} />
          </button>
          <button className={`chip pair ${sheet === "pair" ? "open" : ""}`} onClick={() => toggleSheet("pair")}>
            <MarketIcon asset={currentAsset} small />
            <span className="nm">{shortName(currentAsset)}</span>
            {current?.payout != null && current.payout > 0 && <em>{current.payout}%</em>}
            <ChevronDown size={16} className="chev" />
          </button>
          <button className="chip tfc" onClick={() => { setModePop(false); setSheet("tf"); }}>
            {tfLabel}
            <ChevronDown size={16} />
          </button>
          <button className={`icon dots ${sheet === "more" ? "on" : ""}`} onClick={() => toggleSheet("more")} aria-label="Chart options">
            <Ellipsis size={20} />
          </button>
        </header>
      )}

      <main>
        {tab === "home" && <Home status={status} brokerName={brokerName} onOpenChart={() => go("chart")} />}
        {tab === "signals" && <Signals />}
        {tab === "chart" && (
          <ChartView ref={chartRef} wsBase={wsBase} broker={broker} asset={asset} tf={tf} reloadKey={reloadKey} chartType={chartType} />
        )}
        {tab === "api" && <Api bridge={bridge} setBridge={setBridge} broker={broker} status={status} />}
        {tab === "menu" && <Menu />}

        {tab === "chart" && mode !== "classic" && <div className={`modebadge ${mode}`}>{modeInfo?.label} · coming soon</div>}

        {tab === "chart" && sheet === "pair" && (
          <MarketPicker broker={broker} assets={assets} selected={asset} onPick={(s) => { setAsset(s); close(); }} onClose={close} />
        )}
        {tab === "chart" && sheet === "more" && (
          <ChartMenu
            chart={chartRef.current}
            chartType={chartType}
            onType={setChartType}
            onReset={() => setReloadKey((k) => k + 1)}
            onToast={setToast}
            onClose={close}
          />
        )}
      </main>

      {toast && <div className="toast" role="status">{toast}</div>}

      <div className="navwrap">
        {modePop && (
          <ModePopup
            mode={mode}
            onClose={() => setModePop(false)}
            onPick={(m) => { setMode(m); setModePop(false); setTab("chart"); setSheet(null); }}
          />
        )}
        <nav className="bottom">
          {navBtn("home", "Home", <House size={20} />)}
          {navBtn("signals", "Signals", <Activity size={20} />)}
          <ModeBox mode={mode} open={modePop} onClick={() => { setSheet(null); setModePop((o) => !o); }} />
          {navBtn("api", "API", <Code size={20} />)}
          {navBtn("menu", "Menu", <MenuIcon size={20} />)}
        </nav>
      </div>

      {sheet === "broker" && (
        <BrokerMenu current={broker} onPick={(id) => { setBroker(id); close(); }} onClose={close} />
      )}

      {sheet === "tf" && (
        <Sheet title="Timeframe" onClose={close}>
          {TIMEFRAMES.map((t) => (
            <button key={t.sec} className={`item ${t.sec === tf ? "sel" : ""}`} onClick={() => { setTf(t.sec); close(); }}>
              <span>{t.label}</span>
            </button>
          ))}
        </Sheet>
      )}
    </div>
  );
}
