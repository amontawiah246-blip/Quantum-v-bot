Copy everything in src/ over your project src/. Pages.tsx, BrokerMenu.tsx, Sheet.tsx and bridge are unchanged.
