Replace bridge/server.py (only change: new /api/probe endpoint). Restart the bridge, then open:
  /api/probe?asset=EURUSD_otc&tf=300
and send the whole output.
