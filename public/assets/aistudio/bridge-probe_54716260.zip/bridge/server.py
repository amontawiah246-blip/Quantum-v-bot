"""Pocket Option bridge: SSID -> BinaryOptionsToolsV2 -> HTTP/WebSocket for the dashboard. Real data only.

Candles now come from the library's own get_candles_live(): it subscribes to ticks first, backfills history
(compiled from raw ticks, then chart history), merges both on one clock, replays buffered ticks and releases
the subscription when the browser leaves. That replaces our hand-built merge/resync code.
"""
import asyncio, json, os, time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Optional

from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from BinaryOptionsToolsV2.pocketoption import PocketOptionAsync

SESSION_FILE = "/tmp/pocket_ssid.txt"
SSID = os.environ.get("POCKET_SSID", "").strip()
if not SSID and os.path.exists(SESSION_FILE):
    try:
        SSID = open(SESSION_FILE).read().strip()
    except Exception:
        pass
S = {"client": None, "ready": False, "error": "", "balance": None, "assets": []}
_lock = asyncio.Lock()


def lib_version():
    try:
        from importlib.metadata import version
        for n in ("BinaryOptionsToolsV2", "binaryoptionstoolsv2"):
            try:
                return version(n)
            except Exception:
                pass
    except Exception:
        pass
    return "unknown"


def to_epoch(v) -> float:
    if v is None:
        return time.time()
    if isinstance(v, datetime):
        return v.timestamp()
    try:
        v = float(v)
        return v / 1000 if v > 1e11 else v
    except (TypeError, ValueError):
        return datetime.fromisoformat(str(v).replace("Z", "+00:00")).timestamp()


def field(d, *names):
    for n in names:
        v = d.get(n) if isinstance(d, dict) else getattr(d, n, None)
        if v is not None:
            return v
    return None


def norm(c):
    return {"time": int(to_epoch(field(c, "timestamp", "time"))), "open": float(field(c, "open")),
            "high": float(field(c, "high")), "low": float(field(c, "low")), "close": float(field(c, "close"))}


async def connect() -> Optional[PocketOptionAsync]:
    if S["ready"] and S["client"]:
        return S["client"]
    async with _lock:
        if S["ready"] and S["client"]:
            return S["client"]
        if not SSID:
            S["error"] = "No SSID set. Add POCKET_SSID or paste it on the API screen."
            return None
        try:
            c = PocketOptionAsync(ssid=SSID)
            await c.connect()
            await c.wait_for_assets()
            S["client"] = c
            S["assets"] = await c.active_assets()
            try:
                S["balance"] = float(await c.balance())
            except Exception:
                pass
            S["ready"], S["error"] = True, ""
            return c
        except Exception as e:
            S["error"] = str(e)
            return None


@asynccontextmanager
async def lifespan(_):
    asyncio.create_task(connect())
    yield


app = FastAPI(lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.get("/api/status")
async def status():
    return {"ready": S["ready"], "error": S["error"], "balance": S["balance"], "lib": lib_version(),
            "demo": ('"isDemo":1' in SSID.replace(" ", "")) if SSID else True, "assets": len(S["assets"])}


@app.get("/api/assets")
async def assets():
    if not S["ready"]:
        await connect()
    try:
        if S["client"]:
            S["assets"] = await S["client"].active_assets()
    except Exception:
        pass
    out = []
    for a in S["assets"]:
        sym = field(a, "symbol")
        if not sym:
            continue
        act = field(a, "is_active", "active", "is_open")
        out.append({"symbol": sym, "name": field(a, "name"), "payout": field(a, "payout", "profit", "percent"),
                    "active": True if act is None else bool(act)})
    return out


@app.post("/api/set-ssid")
async def set_ssid(data: dict):
    global SSID
    new = str(data.get("ssid", "")).strip()
    if not new:
        return {"status": "error", "msg": "Empty SSID"}
    SSID = new
    try:
        open(SESSION_FILE, "w").write(new)
    except Exception:
        pass
    S.update(ready=False, client=None, error="")
    asyncio.create_task(connect())
    return {"status": "ok", "msg": "SSID updated, reconnecting..."}


@app.get("/api/diag")
async def diag(asset: str = "EURUSD_otc", tf: int = 60):
    """Library version, clock skew, and the last candles from each source (UTC times) to compare with the app."""
    client = await connect()
    if not client:
        return {"error": S["error"]}
    now = time.time()
    fmt = lambda c: {**c, "utc": datetime.fromtimestamp(c["time"], timezone.utc).strftime("%H:%M:%S")}
    out = {"lib": lib_version(), "asset": asset, "tf": tf, "server_utc_now": datetime.fromtimestamp(now, timezone.utc).strftime("%H:%M:%S")}

    async def last6(name, coro):
        try:
            data = await asyncio.wait_for(coro, 20)
            if isinstance(data, (str, bytes)):
                data = json.loads(data)
            cs = [norm(c) for c in data]
            out[name] = {"count": len(cs), "last": [fmt(c) for c in cs[-6:]]}
            if cs:
                out[name]["newest_vs_now_seconds"] = round(cs[-1]["time"] - now)
        except Exception as e:
            out[name] = {"error": str(e)}

    await last6("history_chart", client.client.history(asset, tf))
    await last6("compiled_from_ticks", client.compile_candles(asset, tf, tf * 10))
    if hasattr(client, "candles"):
        await last6("candles_closed", client.candles(asset, tf, 10))
    # Raw live ticks: symbol, price and clock skew, next to the last history close
    try:
        ref = out.get("history_chart", {}).get("last", [])
        out["last_history_close"] = ref[-1]["close"] if ref else None
        stream = await client.subscribe_symbol(asset)
        ticks = []
        t_end = time.time() + 8
        while time.time() < t_end and len(ticks) < 6:
            try:
                item = await asyncio.wait_for(stream.__anext__(), max(0.1, t_end - time.time()))
            except asyncio.TimeoutError:
                break
            raw = field(item, "price", "close", "rate")
            ticks.append({"symbol": field(item, "symbol", "asset"), "price": raw,
                          "skew_s": round(to_epoch(field(item, "timestamp", "time")) - time.time()),
                          "raw": repr(item)[:160]})
        out["live_ticks"] = ticks
        if not ticks:
            out["live_ticks_note"] = "no ticks in 8 s"
        try:
            await stream.unsubscribe()
        except Exception:
            pass
    except Exception as e:
        out["tick_error"] = str(e)
    return out


@app.get("/api/probe")
async def probe(asset: str = "EURUSD_otc", tf: int = 300):
    """Which request time returns history that lines up with the live price? Tries several clock offsets."""
    client = await connect()
    if not client:
        return {"error": S["error"]}
    try:
        stream = await client.subscribe_symbol(asset)
        item = await asyncio.wait_for(stream.__anext__(), 10)
        live = float(field(item, "price", "close", "rate"))
        try:
            await stream.unsubscribe()
        except Exception:
            pass
    except Exception as e:
        return {"error": f"no live tick: {e}"}
    now = int(time.time())
    fmt = lambda t: datetime.fromtimestamp(t, timezone.utc).strftime("%H:%M")
    rows = []
    for skew in (0, 3600, 7200, 10800, -3600, -7200):
        try:
            raw = await asyncio.wait_for(client.client.get_candles_advanced(asset, tf, tf * 6, now + skew), 20)
            cs = [norm(c) for c in (json.loads(raw) if isinstance(raw, (str, bytes)) else raw)]
            if not cs:
                rows.append({"request_time_offset": skew, "count": 0})
                continue
            last = cs[-1]
            rows.append({"request_time_offset": skew, "count": len(cs), "newest_label_utc": fmt(last["time"]),
                         "label_minus_offset_utc": fmt(last["time"] - skew), "newest_close": last["close"],
                         "gap_to_live": round(last["close"] - live, 5)})
        except Exception as e:
            rows.append({"request_time_offset": skew, "error": str(e)})
    ok = [r for r in rows if "gap_to_live" in r]
    best = min(ok, key=lambda r: abs(r["gap_to_live"]))["request_time_offset"] if ok else None
    return {"lib": lib_version(), "asset": asset, "tf": tf, "now_utc": fmt(now), "live_price": live,
            "rows": rows, "best_request_time_offset": best}


@app.websocket("/ws")
async def ws(sock: WebSocket):
    await sock.accept()
    asset = sock.query_params.get("asset", "EURUSD_otc")
    tf = int(sock.query_params.get("tf", "60"))
    rows = 300
    hours = max(0.25, min(6.0, rows * tf / 3600))
    send_lock = asyncio.Lock()

    async def send(m):
        async with send_lock:
            await sock.send_text(json.dumps(m))

    gen, tasks = None, []
    try:
        client = await connect()
        if not client:
            await send({"type": "error", "msg": S["error"] or "bridge not ready"})
            return
        if not hasattr(client, "get_candles_live"):
            await send({"type": "error", "msg": f"library {lib_version()} has no get_candles_live; upgrade binaryoptionstoolsv2"})
            return
        gen = client.get_candles_live(asset, tf, hours=hours, max_rows=rows)

        async def pump():
            first = True
            async for closed, forming in gen:
                if first:
                    first = False
                    cs = [norm(c) for c in closed]
                    if forming:
                        cs.append(norm(forming))
                    await send({"type": "history", "candles": cs})
                    continue
                if forming:
                    c = norm(forming)
                    await send({"type": "tick", "price": c["close"], "ts": time.time(), "candle": c})
            await send({"type": "error", "msg": "live feed ended, reconnecting"})

        async def watch():
            while True:
                m = await sock.receive()
                if m.get("type") == "websocket.disconnect":
                    return

        tasks = [asyncio.create_task(pump()), asyncio.create_task(watch())]
        done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
        for t in done:
            if t.exception():
                await send({"type": "error", "msg": str(t.exception())})
    except Exception as e:
        try:
            await send({"type": "error", "msg": str(e)})
        except Exception:
            pass
    finally:
        for t in tasks:
            t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        if gen is not None:
            try:
                await gen.aclose()  # runs the library's unsubscribe
            except Exception:
                pass
