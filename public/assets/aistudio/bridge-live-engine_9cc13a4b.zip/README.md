Replace bridge/server.py with this file (it keeps your SSID handling and API routes).
1) pip install -U binaryoptionstoolsv2     (the bridge needs the library's get_candles_live; GET /api/status shows the version in "lib")
2) Open /api/diag?asset=EURUSD_otc&tf=60 and send the output.
