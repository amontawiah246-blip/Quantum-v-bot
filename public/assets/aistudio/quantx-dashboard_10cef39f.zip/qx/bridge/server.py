"""Pocket Option bridge: SSID -> BinaryOptionsToolsV2 -> HTTP/WebSocket for the dashboard.
Real data only: nothing here is simulated.

Run:
  export POCKET_SSID='42["auth",{...}]'     # full string, never commit it
  uvicorn server:app --host 0.0.0.0 --port 8765
"""
import asyncio, json, os, time
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from BinaryOptionsToolsV2.pocketoption import PocketOptionAsync

SSID = os.environ.get("POCKET_SSID", "")
S = {"client": None, "ready": False, "error": "", "balance": None, "assets": []}
_lock = asyncio.Lock()


def to_epoch(v) -> float:
    if v is None:
        return time.time()
    if isinstance(v, datetime):
        return v.timestamp()
    try:
        v = float(v)
        return v / 1000 if v > 1e11 else v
    except (TypeError, ValueError):
        return datetime.fromisoformat(str(v).replace("Z", "+00:00")).timestamp()


def field(d, *names):
    for n in names:
        if isinstance(d, dict) and d.get(n) is not None:
            return d[n]
        if not isinstance(d, dict) and getattr(d, n, None) is not None:
            return getattr(d, n)
    return None


async def connect() -> Optional[PocketOptionAsync]:
    if S["ready"]:
        return S["client"]
    async with _lock:
        if S["ready"]:
            return S["client"]
        if not SSID:
            S["error"] = "POCKET_SSID is not set"
            return None
        try:
            c = PocketOptionAsync(ssid=SSID)
            await c.connect()
            await c.wait_for_assets()
            S["client"] = c
            S["assets"] = await c.active_assets()
            try:
                S["balance"] = float(await c.balance())
            except Exception:
                pass
            S["ready"], S["error"] = True, ""
            return c
        except Exception as e:
            S["error"] = str(e)
            return None


@asynccontextmanager
async def lifespan(_):
    asyncio.create_task(connect())
    yield


app = FastAPI(lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.get("/api/status")
async def status():
    return {"ready": S["ready"], "error": S["error"], "balance": S["balance"],
            "demo": '"isDemo":1' in SSID.replace(" ", ""), "assets": len(S["assets"])}


@app.get("/api/assets")
async def assets():
    if not S["ready"]:
        await connect()
    try:
        S["assets"] = await S["client"].active_assets()  # refresh payouts
    except Exception:
        pass
    out = []
    for a in S["assets"]:
        sym = field(a, "symbol")
        if not sym:
            continue
        out.append({
            "symbol": sym,
            "name": field(a, "name"),
            "payout": field(a, "payout", "profit", "percent"),
            "active": bool(field(a, "is_active", "active", "is_open") if field(a, "is_active", "active", "is_open") is not None else True),
        })
    return out


@app.websocket("/ws")
async def ws(sock: WebSocket):
    await sock.accept()
    asset = sock.query_params.get("asset", "EURUSD_otc")
    tf = int(sock.query_params.get("tf", "60"))

    async def send(m):
        await sock.send_text(json.dumps(m))

    try:
        client = await connect()
        if not client:
            await send({"type": "error", "msg": S["error"] or "bridge not ready"})
            return

        cur = None
        try:
            hist = await asyncio.wait_for(client.get_candles(asset, tf, tf * 150), 10)
            by_t = {}
            for c in hist:
                t = int(to_epoch(field(c, "time", "timestamp")))
                by_t[t] = {"time": t, "open": float(field(c, "open")), "high": float(field(c, "high")),
                           "low": float(field(c, "low")), "close": float(field(c, "close"))}
            candles = sorted(by_t.values(), key=lambda x: x["time"])
            await send({"type": "history", "candles": candles})
            cur = dict(candles[-1]) if candles else None
        except Exception as e:
            await send({"type": "info", "msg": f"history unavailable: {e}"})

        stream = await client.subscribe_symbol(asset)
        async for item in stream:
            raw = field(item, "price", "close", "rate")
            if raw is None:
                continue
            price = float(raw)
            ts = to_epoch(field(item, "time", "timestamp"))
            b = int(ts // tf * tf)
            if cur and cur["time"] == b:
                cur["high"] = max(cur["high"], price)
                cur["low"] = min(cur["low"], price)
                cur["close"] = price
            elif not cur or b > cur["time"]:
                cur = {"time": b, "open": price, "high": price, "low": price, "close": price}
            else:
                continue  # stale tick for an older candle
            await send({"type": "tick", "price": price, "ts": ts, "candle": cur})
    except (WebSocketDisconnect, RuntimeError):
        pass
    except Exception as e:
        try:
            await send({"type": "error", "msg": str(e)})
        except Exception:
            pass
