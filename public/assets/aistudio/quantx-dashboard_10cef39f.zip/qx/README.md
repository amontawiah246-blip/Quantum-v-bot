# QuantX dashboard (real data only)

## 1. Bridge
cd bridge
pip install -r requirements.txt
export POCKET_SSID='42["auth",{...}]'
uvicorn server:app --host 0.0.0.0 --port 8765

## 2. Dashboard
cd web
npm install
npm run dev        # http://localhost:5173

Phone on the same Wi-Fi: open http://<computer-ip>:5173, then API tab > Bridge address = <computer-ip>:8765
