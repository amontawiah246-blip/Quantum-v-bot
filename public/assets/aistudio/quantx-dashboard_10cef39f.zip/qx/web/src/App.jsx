import { useEffect, useMemo, useState } from "react";
import ChartView from "./ChartView.jsx";
import Sheet from "./Sheet.jsx";
import { Home, Signals, Api, Menu } from "./Pages.jsx";
import { grouped, prettyName, TIMEFRAMES, BROKERS } from "./assets.js";

const defaultBridge = () => localStorage.getItem("bridge") || `${location.hostname}:8765`;

export default function App() {
  const [tab, setTab] = useState("chart");
  const [bridge, setBridgeState] = useState(defaultBridge);
  const [broker, setBroker] = useState("pocket");
  const [asset, setAsset] = useState("EURUSD_otc");
  const [tf, setTf] = useState(60);
  const [sheet, setSheet] = useState(null); // broker | pair | tf | more
  const [q, setQ] = useState("");
  const [assets, setAssets] = useState([]);
  const [status, setStatus] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);

  const setBridge = (v) => { localStorage.setItem("bridge", v); setBridgeState(v); };
  const http = `http://${bridge}`, wsBase = `ws://${bridge}`;

  // Status + asset list (payouts change, so refresh every minute).
  useEffect(() => {
    let dead = false;
    const load = async () => {
      try {
        const s = await (await fetch(`${http}/api/status`)).json();
        if (!dead) setStatus(s);
        const a = await (await fetch(`${http}/api/assets`)).json();
        if (!dead) setAssets(a);
      } catch { if (!dead) setStatus(null); }
    };
    load();
    const id = setInterval(load, status?.ready ? 60000 : 3000);
    return () => { dead = true; clearInterval(id); };
  }, [http, status?.ready]);

  const current = assets.find((a) => a.symbol === asset);
  const label = current ? prettyName(current) : prettyName({ symbol: asset });
  const groups = useMemo(() => {
    const needle = q.trim().toLowerCase();
    const list = needle ? assets.filter((a) => (prettyName(a) + a.symbol).toLowerCase().includes(needle)) : assets;
    return grouped(list);
  }, [assets, q]);
  const tfLabel = TIMEFRAMES.find((t) => t.sec === tf)?.label;
  const brokerName = BROKERS.find((b) => b.id === broker).name;

  const close = () => { setSheet(null); setQ(""); };

  return (
    <div className="app">
      {tab === "chart" && (
        <header className="top">
          <button className="chip" onClick={() => setSheet("broker")}>{brokerName} ▾</button>
          <button className="chip pair" onClick={() => setSheet("pair")}>
            <span>{label}</span>
            {current?.payout != null && <em>{current.payout}%</em>}
            <i>▾</i>
          </button>
          <button className="chip" onClick={() => setSheet("tf")}>{tfLabel} ▾</button>
          <button className="icon" onClick={() => setSheet("more")} aria-label="More">⋯</button>
        </header>
      )}

      <main>
        {tab === "home" && <Home status={status} onOpenChart={() => setTab("chart")} />}
        {tab === "signals" && <Signals />}
        {tab === "chart" && <ChartView wsBase={wsBase} asset={asset} tf={tf} reloadKey={reloadKey} />}
        {tab === "api" && <Api bridge={bridge} setBridge={setBridge} />}
        {tab === "menu" && <Menu />}
      </main>

      <nav className="bottom">
        {[["home", "Home", "⌂"], ["signals", "Signals", "∿"], ["chart", "Chart", "▥"], ["api", "API", "</>"], ["menu", "Menu", "≡"]].map(([id, name, ic]) => (
          <button key={id} className={tab === id ? "on" : ""} onClick={() => setTab(id)}><span>{ic}</span>{name}</button>
        ))}
      </nav>

      {sheet === "broker" && (
        <Sheet title="Broker" onClose={close}>
          {BROKERS.map((b) => (
            <button key={b.id} disabled={!b.ready} className={`item ${broker === b.id ? "sel" : ""}`}
              onClick={() => { setBroker(b.id); close(); }}>
              <span>{b.name}<small>{b.note}</small></span>
            </button>
          ))}
        </Sheet>
      )}

      {sheet === "pair" && (
        <Sheet title="Pairs" onClose={close}>
          <input className="search" placeholder="Search pairs" value={q} onChange={(e) => setQ(e.target.value)} />
          {!assets.length && <p className="muted pad">Pairs load once the bridge is connected.</p>}
          {groups.map((g) => (
            <section key={g.group}>
              <h3>{g.group}</h3>
              {g.items.map((a) => (
                <button key={a.symbol} disabled={!a.active} className={`item ${a.symbol === asset ? "sel" : ""}`}
                  onClick={() => { setAsset(a.symbol); close(); }}>
                  <span>{a.label}</span>
                  <b>{a.active ? (a.payout != null ? `${a.payout}%` : "") : "Closed"}</b>
                </button>
              ))}
            </section>
          ))}
        </Sheet>
      )}

      {sheet === "tf" && (
        <Sheet title="Timeframe" onClose={close}>
          {TIMEFRAMES.map((t) => (
            <button key={t.sec} className={`item ${t.sec === tf ? "sel" : ""}`} onClick={() => { setTf(t.sec); close(); }}>
              <span>{t.label}</span>
            </button>
          ))}
        </Sheet>
      )}

      {sheet === "more" && (
        <Sheet title="Chart" onClose={close}>
          <button className="item" onClick={() => { setReloadKey((k) => k + 1); close(); }}><span>Reload chart data</span></button>
          <p className="muted pad">Times show in your device's time zone.</p>
        </Sheet>
      )}
    </div>
  );
}
