import { BROKERS } from "./assets.js";

export function Home({ status, onOpenChart }) {
  return (
    <div className="page">
      <h1>QuantX</h1>
      <div className="card">
        <div className="row"><span>Bridge</span><b className={status?.ready ? "up" : "down"}>{status?.ready ? "Connected" : status ? "Not ready" : "Offline"}</b></div>
        <div className="row"><span>Account</span><b>{status?.ready ? (status.demo ? "Demo" : "Real") : "—"}</b></div>
        <div className="row"><span>Balance</span><b>{status?.balance != null ? `$${status.balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}` : "—"}</b></div>
        <div className="row"><span>Assets</span><b>{status?.assets ?? "—"}</b></div>
        {status?.error && <p className="warn">{status.error}</p>}
      </div>
      <button className="primary" onClick={onOpenChart}>Open chart</button>
    </div>
  );
}

export function Signals() {
  return (
    <div className="page">
      <h1>Signals</h1>
      <p className="muted">Strategy signals will live here, apart from the chart. Nothing is generated yet.</p>
    </div>
  );
}

export function Api({ bridge, setBridge }) {
  return (
    <div className="page">
      <h1>API</h1>
      <label className="field">Bridge address
        <input value={bridge} onChange={(e) => setBridge(e.target.value)} spellCheck={false} />
      </label>
      <p className="muted">The SSID stays on the bridge as POCKET_SSID. It is never typed into this page.</p>
      <div className="card">
        {BROKERS.map((b) => (
          <div className="row" key={b.id}><span>{b.name}<small>{b.note}</small></span><b className={b.ready ? "up" : "muted"}>{b.ready ? "Active" : "Soon"}</b></div>
        ))}
      </div>
    </div>
  );
}

export function Menu() {
  return (
    <div className="page">
      <h1>Menu</h1>
      <p className="muted">Settings, trade history and bot controls will be added here as separate screens.</p>
    </div>
  );
}
