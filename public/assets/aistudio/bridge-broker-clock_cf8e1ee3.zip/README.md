Replace bridge/server.py (nothing else changes; /api/diag and /api/set-ssid stay as before; /api/probe is removed).
Restart the bridge, then open /api/diag?asset=EURUSD_otc&tf=60 and send the output.
