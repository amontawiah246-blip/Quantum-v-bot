Replace bridge/server.py. Only /api/diag changes: it now also reports where each data source ends
("sources") and which candles are missing between the newest candle and now ("missing_candles_before_now").
