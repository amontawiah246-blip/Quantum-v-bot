Drop these 3 files over the same paths in your project:
  bridge/server.py   (stability fixes + /api/diag)
  src/ChartView.tsx  (1-line change: resync no longer jumps the chart)
  server.ts          (removes the SSID hardcoded in the code)
Then set POCKET_SSID as a secret/env var, or paste it on the API screen.
