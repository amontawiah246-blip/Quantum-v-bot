import React from "react";
import { BROKERS } from "./assets";

// Simple brand-neutral marks (no trademarked artwork bundled): a coloured tile with a glyph.
const MARKS: Record<string, { bg: string; fg: string; glyph: React.ReactNode }> = {
  quotex: {
    bg: "#10192e", fg: "#cfd8f3",
    glyph: (
      <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
        <path d="M5 18V8M9 18V5M13 18V9M17 18V6M21 18V10" />
      </svg>
    ),
  },
  iqoption: { bg: "#ff6a1a", fg: "#ffffff", glyph: <b style={{ fontSize: 15, letterSpacing: 0.5 }}>IQ</b> },
  pocket: { bg: "#0f2a1f", fg: "#34d399", glyph: <b style={{ fontSize: 17 }}>P</b> },
  tradowix: {
    bg: "#ffffff", fg: "#0a1020",
    glyph: (
      <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M5 9h12l-3-3M19 15H7l3 3" />
      </svg>
    ),
  },
  binolla: { bg: "#ffffff", fg: "#2f6bff", glyph: <b style={{ fontSize: 20 }}>B</b> },
};

export function BrokerLogo({ id, size = 38 }: { id: string; size?: number }) {
  const m = MARKS[id] || MARKS.quotex;
  return (
    <span className="blogo" style={{ background: m.bg, color: m.fg, width: size, height: size }}>
      {m.glyph}
    </span>
  );
}

interface Props {
  current: string;
  onPick: (id: string) => void;
  onClose: () => void;
}

// Dropdown that opens right under the broker button (top-left), like the Quotex Live Chart page.
export default function BrokerMenu({ current, onPick, onClose }: Props) {
  return (
    <div className="bm-scrim" onClick={onClose}>
      <div className="bm" role="listbox" aria-label="Broker" onClick={(e) => e.stopPropagation()}>
        <div className="bm-title">BROKER</div>
        {BROKERS.map((b) => (
          <button
            key={b.id}
            role="option"
            aria-selected={current === b.id}
            disabled={!b.ready}
            className={`bm-item ${current === b.id ? "sel" : ""}`}
            onClick={() => onPick(b.id)}
          >
            <BrokerLogo id={b.id} />
            <span className="bm-name">
              {b.name.toUpperCase()}
              {!b.ready && <small>Coming soon</small>}
            </span>
            {current === b.id && <span className="bm-check">✓</span>}
          </button>
        ))}
      </div>
    </div>
  );
}
