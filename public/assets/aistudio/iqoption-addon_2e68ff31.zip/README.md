IQ Option add-on. Copy these files over the same paths in your project (10 files), then restart.

New: bridge/iqoption_provider.py, bridge/iq_assets.json (asset list from the iqoption repo)
Changed: bridge/server.py, bridge/requirements.txt, src/assets.ts, src/assets.test.ts, src/BrokerMenu.tsx,
         src/ChartView.tsx, src/Pages.tsx, server.ts

Login (read-only, the bridge never trades):
  env  IQ_EMAIL + IQ_PASSWORD   or   IQ_SSID (the "ssid" cookie from a logged-in browser; needed with 2-step login)
  or   API screen > pick IQ Option in the broker menu > enter the login.

Check:  /api/diag?broker=iqoption&asset=EURUSD_otc&tf=60
